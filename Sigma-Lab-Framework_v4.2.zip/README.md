# Sigma‑Lab — Framework

> Transparent procedural ethics engine for AI‑human deliberation.
> Non‑Harm · Stability · Resilience · Equity. Open, auditable, and configurable.

## Quickstart
```bash
python -m pip install -U pip
pip install -r requirements.txt
python sigma_lab_v4_2.py --demo ai --pretty
```
See `notebooks/SigmaLab_Demo.ipynb` for a visual walkthrough.
