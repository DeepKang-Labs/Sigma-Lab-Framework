# Security Policy

No sensitive data should be processed with this tool. If you discover a vulnerability,
please open a private security advisory or email the maintainers listed in the repository.
