# Contributing to Sigma‑Lab

1. Fork the repo and create a branch off `main`.
2. Run quick checks:
   ```bash
   python -m pip install -U pip
   pip install -r requirements.txt
   bash scripts/lint.sh
   python sigma_lab_v4_2.py --demo ai --pretty
   ```
3. Add tests in `tests/` and run:
   ```bash
   python -m pytest -q
   ```
4. Open a Pull Request with a clear description (what/why/how).
