# Changelog

## v4.2 — 2025-10-24
- Public, optimized release of Sigma‑Lab Framework
- Robust input validation, value functions, fairness (Gini), veto guardrails
- CLI with `--demo` contexts and pretty JSON output
- Tests & notebook added; scripts for lint and quick run
