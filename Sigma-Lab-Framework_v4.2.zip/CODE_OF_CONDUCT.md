# Code of Conduct — DeepKang-Labs

We are committed to a harassment‑free, inclusive community. Be respectful. Assume good intent.
No discrimination, hate speech, or personal attacks. Report issues via GitHub Issues or email
maintainers. Serious violations may result in removal from the community.
