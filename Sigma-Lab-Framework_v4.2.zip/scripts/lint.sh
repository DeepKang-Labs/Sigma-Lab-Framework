#!/usr/bin/env bash
python -m pip install -U pip >/dev/null 2>&1
