#!/usr/bin/env bash
python sigma_lab_v4_2.py --demo ai --pretty
python sigma_lab_v4_2.py --demo healthcare --pretty
python sigma_lab_v4_2.py --demo public --pretty
