from __future__ import annotations
from dataclasses import dataclass, field, replace
from typing import Any, Dict, List, Optional, Tuple
import numpy as np, argparse, json, math, sys

def clip01(x: float) -> float:
    return float(max(0.0, min(1.0, x)))

def safe_mean(xs: List[float]) -> float:
    return float(np.mean(xs)) if xs else 0.0

@dataclass
class ValueFunction:
    kind: str = "linear"
    params: Dict[str, Any] = field(default_factory=dict)
    def __call__(self, x: float) -> float:
        x = clip01(x)
        k = self.kind.lower()
        if k == "linear":
            return x
        if k == "exp":
            a = float(self.params.get("a", 3.0))
            return clip01((math.exp(a*x)-1.0)/(math.exp(a)-1.0+1e-12))
        if k == "logistic":
            kk = float(self.params.get("k", 12.0))
            x0 = float(self.params.get("x0", 0.5))
            return clip01(1.0/(1.0+math.exp(-kk*(x-x0))))
        if k == "piecewise":
            pts = self.params.get("points", [(0,0),(1,1)])
            pts = sorted([(float(a), float(b)) for a,b in pts], key=lambda t: t[0])
            xs, ys = zip(*pts)
            return float(np.interp(x, xs, ys))
        return x

def gini_coefficient(x: List[float]) -> float:
    a = np.array([max(0.0, float(v)) for v in x], dtype=float)
    if a.size == 0: return 0.0
    a_sorted = np.sort(a)
    n = a.size
    denom = a_sorted.sum()
    if denom <= 1e-12: return 0.0
    i = np.arange(1, n+1)
    g = 1.0 - 2.0*np.sum((n - i + 0.5)*a_sorted)/(n*denom)
    return clip01(float(abs(g)))

@dataclass
class HarmModel:
    base_agg: str = "max"
    base_agg_weight: float = 0.5
    base_weight: float = 0.7
    irreversibility_weight: float = 0.3
    formula: str = ("expected_harm = base_risk * clamp(base_weight + "
                    "irreversibility_weight * irreversibility)")
    rationale: str = ("Irreversibility amplifies base risk; base via max/mean/weighted.")

@dataclass
class StabilityModel:
    mean_weight: float = 0.6
    max_weight: float = 0.4
    formula: str = "stability = 1 - (mw*mean_r + xw*max_r)"
    rationale: str = "Balance average operational risk with worst hotspot."

@dataclass
class Thresholds:
    non_harm_floor: float = 0.35
    veto_irreversibility: float = 0.7

@dataclass
class EthicalWeights:
    non_harm: float = 0.4
    stability: float = 0.2
    resilience: float = 0.2
    equity: float = 0.2
    def norm(self) -> Dict[str, float]:
        v = np.array([self.non_harm, self.stability, self.resilience, self.equity], dtype=float)
        s = float(v.sum())
        if s < 1e-12:
            return {"non_harm":0.25,"stability":0.25,"resilience":0.25,"equity":0.25}
        return {"non_harm":float(v[0]/s), "stability":float(v[1]/s),
                "resilience":float(v[2]/s), "equity":float(v[3]/s)}

@dataclass
class SigmaConfig:
    weights: EthicalWeights = field(default_factory=EthicalWeights)
    thresholds: Thresholds = field(default_factory=Thresholds)
    value_functions: Dict[str, ValueFunction] = field(default_factory=lambda: {
        "non_harm": ValueFunction("linear"),
        "stability": ValueFunction("linear"),
        "resilience": ValueFunction("linear"),
        "equity": ValueFunction("linear"),
    })
    verdict_acceptance_threshold: float = 0.65
    no_aggregation: bool = True

@dataclass
class Stakeholder:
    name: str
    vulnerability: float = 0.0
    impact_benefit: float = 0.0
    weight: float = 1.0

@dataclass
class OptionContext:
    name: str
    short_term_risk: float
    long_term_risk: float
    irreversibility_risk: float
    stakeholders: List[Stakeholder]
    stability_risks: Dict[str, float] = field(default_factory=dict)
    resilience_features: Dict[str, float] = field(default_factory=dict)

class SigmaLab:
    def __init__(self, config: SigmaConfig, harm: HarmModel = None, stab: StabilityModel = None):
        self.cfg = config
        self.harm = harm or HarmModel()
        self.stab = stab or StabilityModel()

    def validate_context(self, ctx: OptionContext) -> List[str]:
        errs = []
        for n,val in [("short_term_risk",ctx.short_term_risk),("long_term_risk",ctx.long_term_risk),
                      ("irreversibility_risk",ctx.irreversibility_risk)]:
            if not (0<=val<=1): errs.append(f"{n} out of [0,1]: {val}")
        if not ctx.stakeholders: errs.append("At least one stakeholder required")
        for s in ctx.stakeholders:
            if not (0<=s.vulnerability<=1): errs.append(f"vulnerability out of [0,1]: {s.name}")
            if not (0<=s.impact_benefit<=1): errs.append(f"impact_benefit out of [0,1]: {s.name}")
            if s.weight < 0: errs.append(f"negative weight: {s.name}")
        return errs

    def _base_risk(self, st: float, lt: float) -> float:
        agg = self.harm.base_agg
        if agg not in {"max","mean","weighted"}: agg = "max"
        if agg == "max": return clip01(max(st, lt))
        if agg == "mean": return clip01((st+lt)/2.0)
        w = clip01(self.harm.base_agg_weight)
        return clip01(w*st + (1.0-w)*lt)

    def _eval_non_harm(self, ctx: OptionContext):
        base = self._base_risk(ctx.short_term_risk, ctx.long_term_risk)
        factor = clip01(self.harm.base_weight + self.harm.irreversibility_weight*clip01(ctx.irreversibility_risk))
        expected = base * factor
        harms = [clip01(expected * clip01(s.vulnerability)) for s in ctx.stakeholders]
        harm = clip01(safe_mean(harms))
        score = clip01(1.0 - harm)
        return score, {"base_risk": base, "factor": factor, "stakeholder_expected_harm": harms, "aggregate_expected_harm": harm}

    def _eval_stability(self, ctx: OptionContext):
        risks = [clip01(v) for v in ctx.stability_risks.values()] or [0.0]
        mean_r = safe_mean(risks); max_r = max(risks)
        mw, xw = clip01(self.stab.mean_weight), clip01(self.stab.max_weight)
        raw = clip01(1.0 - (mw*mean_r + xw*max_r))
        return raw, {"mean_risk": mean_r, "max_risk": max_r, "raw_stability": raw}

    def _eval_resilience(self, ctx: OptionContext):
        feats = [clip01(v) for v in ctx.resilience_features.values()] or [0.0]
        avg = safe_mean(feats)
        return avg, {"avg_features": avg, "features_count": len(feats)}

    def _eval_equity(self, ctx: OptionContext):
        benefits = [clip01(s.impact_benefit)*max(0.0,s.weight) for s in ctx.stakeholders] or [0.0]
        g = gini_coefficient(benefits)
        equity = clip01(1.0 - g)
        return equity, {"gini": g, "benefits": benefits}

    def mcda_score(self, scores: Dict[str,float]) -> Optional[float]:
        if self.cfg.no_aggregation: return None
        w = self.cfg.weights.norm()
        return clip01(sum(scores[k]*w[k] for k in scores.keys()))

    def veto(self, ctx: OptionContext, scores: Dict[str,float]) -> Dict[str,Any]:
        th = self.cfg.thresholds
        v = []
        if scores["non_harm"] < th.non_harm_floor:
            v.append(f"Non-harm below floor: {scores['non_harm']:.2f} < {th.non_harm_floor:.2f}")
        if clip01(ctx.irreversibility_risk) > th.veto_irreversibility:
            v.append(f"Irreversibility risk veto: {ctx.irreversibility_risk:.2f} > {th.veto_irreversibility:.2f}")
        return {"vetoes": v, "pass": len(v)==0}

    def profile(self, ctx: OptionContext) -> Dict[str,Any]:
        nh_raw, nh_d = self._eval_non_harm(ctx)
        st_raw, st_d = self._eval_stability(ctx)
        re_raw, re_d = self._eval_resilience(ctx)
        eq_raw, eq_d = self._eval_equity(ctx)
        vf = self.cfg.value_functions
        scores = {
            "non_harm": vf["non_harm"](nh_raw),
            "stability": vf["stability"](st_raw),
            "resilience": vf["resilience"](re_raw),
            "equity": vf["equity"](eq_raw),
        }
        return {"scores": scores, "diagnostics": {
            "raw": {"non_harm":nh_raw,"stability":st_raw,"resilience":re_raw,"equity":eq_raw},
            "details": {"non_harm":nh_d,"stability":st_d,"resilience":re_d,"equity":eq_d}
        }}

    def diagnose(self, ctx: OptionContext, verdict_opt_in: bool=False) -> Dict[str,Any]:
        errs = self.validate_context(ctx)
        if errs: return {"input_errors": errs}
        prof = self.profile(ctx)
        scores = prof["scores"]
        vt = self.veto(ctx, scores)
        out = {"scores": scores, "diagnostics": prof["diagnostics"], "veto": vt,
               "semantics": {"note":"Procedural diagnostic only. No moral truth claim.","verdict_procedural": None}}
        if not self.cfg.no_aggregation:
            out["mcda_score"] = self.mcda_score(scores)
        if verdict_opt_in:
            mcda = self.mcda_score(scores) or 0.0
            if vt["pass"] and mcda >= self.cfg.verdict_acceptance_threshold:
                out["semantics"]["verdict_procedural"] = {"status":"ACCEPTABLE"}
            else:
                out["semantics"]["verdict_procedural"] = {"status":"REVIEW"}
        return out

def demo_context(domain: str):
    domain = (domain or "").lower()
    if domain == "ai":
        cfg = SigmaConfig(no_aggregation=False)
        ctx = OptionContext(
            name="BiasAudit-Release",
            short_term_risk=0.25, long_term_risk=0.45, irreversibility_risk=0.6,
            stakeholders=[
                Stakeholder("minority_users", vulnerability=0.8, impact_benefit=0.55),
                Stakeholder("majority_users", vulnerability=0.3, impact_benefit=0.65),
                Stakeholder("dev_team", vulnerability=0.2, impact_benefit=0.6),
            ],
            stability_risks={"ops":0.2,"scale":0.3,"security":0.25},
            resilience_features={"rollback":0.7,"canary":0.6},
        )
        return cfg, ctx
    if domain == "healthcare":
        cfg = SigmaConfig()
        ctx = OptionContext(
            name="TriageAssist-v1",
            short_term_risk=0.35, long_term_risk=0.2, irreversibility_risk=0.5,
            stakeholders=[
                Stakeholder("critical_patients", vulnerability=0.9, impact_benefit=0.8),
                Stakeholder("non_critical_patients", vulnerability=0.5, impact_benefit=0.55),
                Stakeholder("staff", vulnerability=0.3, impact_benefit=0.6),
            ],
            stability_risks={"ops":0.25,"capacity":0.3},
            resilience_features={"backup_staff":0.6,"failover_units":0.5},
        )
        return cfg, ctx
    cfg = SigmaConfig()
    ctx = OptionContext(
        name="UrbanSensors-Deploy",
        short_term_risk=0.2, long_term_risk=0.4, irreversibility_risk=0.45,
        stakeholders=[
            Stakeholder("residents", vulnerability=0.6, impact_benefit=0.62),
            Stakeholder("small_business", vulnerability=0.4, impact_benefit=0.58),
            Stakeholder("municipality", vulnerability=0.3, impact_benefit=0.6),
        ],
        stability_risks={"ops":0.25,"privacy":0.35,"maintenance":0.3},
        resilience_features={"redundancy":0.55,"incident_response":0.6},
    )
    return cfg, ctx

def main():
    ap = argparse.ArgumentParser(description="Sigma‑Lab v4.2 — Procedural Ethics Framework")
    ap.add_argument("--demo", type=str, choices=["ai","healthcare","public"], help="Run a built‑in demo context")
    ap.add_argument("--verdict", action="store_true", help="Include procedural verdict")
    ap.add_argument("--pretty", action="store_true", help="Pretty JSON output")
    args = ap.parse_args()

    if args.demo:
        cfg, ctx = demo_context(args.demo)
    else:
        print("Use --demo [ai|healthcare|public] for a quick run.", file=sys.stderr)
        sys.exit(1)

    engine = SigmaLab(cfg)
    out = engine.diagnose(ctx, verdict_opt_in=bool(args.verdict))
    print(json.dumps(out, indent=2 if args.pretty else None, ensure_ascii=False))

if __name__ == "__main__":
    main()
