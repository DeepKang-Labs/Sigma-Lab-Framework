import unittest
from sigma_lab_v4_2 import SigmaLab, SigmaConfig, demo_context, OptionContext, Stakeholder

class SigmaCoreTests(unittest.TestCase):
    def test_demo_ai_runs(self):
        cfg, ctx = demo_context("ai")
        engine = SigmaLab(cfg)
        out = engine.diagnose(ctx, verdict_opt_in=True)
        self.assertIn("scores", out)
        self.assertIn("veto", out)

    def test_validation(self):
        cfg, ctx = demo_context("public")
        bad = OptionContext(name="bad", short_term_risk=1.3, long_term_risk=0.2,
                            irreversibility_risk=0.2, stakeholders=[])
        engine = SigmaLab(cfg)
        out = engine.diagnose(bad)
        self.assertIn("input_errors", out)

if __name__ == "__main__":
    unittest.main()
